create function polygon(circle) returns polygon
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.polygon(12, $1)
$$;
